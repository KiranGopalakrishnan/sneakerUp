<?php
include 'database.php';
$db=new database();
$currentRaffle = $db->getCurrentRaffle();
$now = date("Y-m-d H:i:s");
var_dump($currentRaffle);
if($now>$currentRaffle[0]["endTime"]){
    $db->decideWinner($currentRaffle[0]["raffleID"]);
    $db->removeAllStatuses("0");
    $upcoming  = $db->setNextRaffle();
}
?>