<?php
/**
 * Created by IntelliJ IDEA.
 * User: Kiran
 * Date: 16-02-2017
 * Time: 01:10 AM
 */
/*
 $db = "snkrup";
 $user = "snkrup";
 $pass = "snkrup";
 $host="localhost";*/
$db = "anouxxjh_snkrup";
$user = "anouxxjh_snkrup";
$pass = "snkrup2017";
$host="localhost";